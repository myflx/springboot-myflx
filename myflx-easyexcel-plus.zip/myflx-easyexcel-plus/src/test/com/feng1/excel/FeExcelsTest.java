package com.feng1.excel;

import com.feng1.excel.template.DemoTemplate;
import com.feng1.excel.template.DemoTemplate01;
import com.feng1.excel.util.FeExcelSheetBuilder;
import com.feng1.excel.util.FeExcels;
import org.junit.jupiter.api.Test;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class FeExcelsTest {
    @Test
    public void builderTest() throws FileNotFoundException {
        String fileName = "fe_simpleWrite" + System.currentTimeMillis() + ".xlsx";
        final DemoTemplate demoVO = new DemoTemplate();
        demoVO.setDateTime("2020-01-21");
        demoVO.setSupplierName("slfsdfj");
        final DemoTemplate demoVO2 = new DemoTemplate();
        demoVO2.setDateTime("2020-01-21");
        demoVO.setDemoVO(demoVO2);


        final DemoData demoData = new DemoData();
        demoData.setDate(new Date());
        demoData.setDoubleData((double) 111);
        demoData.setString("dsfsf");
        demoData.setIgnore("ignore");
        demoData.setSdfs((double) 3434);
        List<Object> payload = new ArrayList<>();
        payload.add(demoData);
        FeExcels.newExcel(demoVO).addPayLoad(payload).export(new FileOutputStream(new File(TestFileUtil.getPath() + fileName)));
    }

    @Test
    public void builderTest2() throws FileNotFoundException {
        String fileName = "fe_simpleWrite" + System.currentTimeMillis() + ".xlsx";
        final DemoTemplate01 demoVO = new DemoTemplate01();
        demoVO.setDateTime("2020-01-21");
        demoVO.setSupplierName("slfsdfj");
        final DemoTemplate01 demoVO2 = new DemoTemplate01();
        demoVO2.setDateTime("2020-01-21");
        demoVO.setDemoVO(demoVO2);


        final DemoData demoData = new DemoData();
        demoData.setDate(new Date());
        demoData.setDoubleData((double) 111);
        demoData.setString("dsfsf");
        demoData.setIgnore("ignore");
        demoData.setSdfs((double) 3434);
        List<Object> payload = new ArrayList<>();
        payload.add(demoData);
        FeExcels.newExcel(demoVO).addPayLoad(payload).export(new FileOutputStream(new File(TestFileUtil.getPath() + fileName)));
    }


    @Test
    public void builderTest3() throws FileNotFoundException {
        String fileName = "fe_simpleWrite" + System.currentTimeMillis() + ".xlsx";
        final DemoTemplate01 demoVO = new DemoTemplate01();
        demoVO.setDateTime("2020-01-21");
        demoVO.setSupplierName("slfsdfj");


        final DemoData demoData = new DemoData();
        demoData.setDate(new Date());
        demoData.setDoubleData((double) 111);
        demoData.setString("dsfsf");
        demoData.setIgnore("ignore");
        demoData.setSdfs((double) 3434);
        List<Object> payload = new ArrayList<>();
        payload.add(demoData);



        final DemoTemplate demoVO3 = new DemoTemplate();
        demoVO3.setDateTime("2020-01-21");
        demoVO3.setSupplierName("slfsdfj");


        final FeExcelSheetBuilder feExcelSheetBuilder = FeExcels.newExcel(demoVO).addPayLoad(payload);
        final FeExcelSheetBuilder feExcelSheetBuilder2 = FeExcels.newExcel(demoVO3).addPayLoad(payload);
        feExcelSheetBuilder.addBuilder(feExcelSheetBuilder2);
        feExcelSheetBuilder.exportAll(new FileOutputStream(new File(TestFileUtil.getPath() + fileName)));
    }

}