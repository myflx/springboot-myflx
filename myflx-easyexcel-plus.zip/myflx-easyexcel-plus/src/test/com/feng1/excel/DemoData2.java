package com.feng1.excel;

import com.alibaba.excel.annotation.ExcelIgnore;
import com.alibaba.excel.annotation.ExcelProperty;
import lombok.Data;

import java.util.Date;

@Data
public class DemoData2 {
    @ExcelProperty("字符串标题1")
    private String string1;
    @ExcelProperty("字符串标题1")
    private String string;
    @ExcelProperty("日期标题1")
    private Date date1;
    @ExcelProperty("日期标题1")
    private Date date;
    @ExcelProperty("数字标题1")
    private Double doubleData1;
    @ExcelProperty("数字标题1")
    private Double doubleData;
    /**
     * 忽略这个字段
     */
    @ExcelIgnore
    private String ignore;
}