package com.feng1.excel;

import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.write.builder.ExcelWriterBuilder;
import com.alibaba.excel.write.metadata.WriteSheet;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.regex.Pattern;

/**
 * @Description TODO
 * @Author LuoShangLin
 * @Date 2020/12/25 20:05
 * @Since V2.13.0
 */
public class Test {
    private static final Pattern PATTERN = Pattern.compile("^[A-Za-z0-9]+$");
    @org.junit.Test
    public void simpleWrite1() {

        System.out.println(PATTERN.matcher("22a3").matches());
    }
    @org.junit.Test
    public void simpleWrite() {
        // 写法1
        String fileName = TestFileUtil.getPath() + "simpleWrite" + System.currentTimeMillis() + ".xlsx";
        // 这里 需要指定写用哪个class去写，然后写到第一个sheet，名字为模板 然后文件流会自动关闭
        // 如果这里想使用03 则 传入excelType参数即可
        //EasyExcel.write(fileName, DemoData.class).sheet("模板").doWrite(data2());

        // 写法2
        fileName = TestFileUtil.getPath() + "simpleWrite" + System.currentTimeMillis() + ".xlsx";
        // 这里 需要指定写用哪个class去写
        ExcelWriter excelWriter = null;
        try {
            excelWriter = EasyExcel.write(fileName, DemoData.class).build();
            WriteSheet writeSheet = EasyExcel.writerSheet("模板").build();
            WriteSheet writeSheet2 = EasyExcel.writerSheet("模板1").build();
            excelWriter.write(data(), writeSheet);
            excelWriter.write(data(), writeSheet2);
        } finally {
            // 千万别忘记finish 会帮忙关闭流
            if (excelWriter != null) {
                excelWriter.finish();
            }
        }

        /*InputStream templateFileName = this.getClass().getClassLoader().getResourceAsStream("static/distributeDetailHis.xlsx");
        EasyExcel.write(fileName, DemoData.class).withTemplate(templateFileName).sheet().doWrite(new ArrayList());*/

        try {
//            FeExcels.export(new FileOutputStream(new File(fileName)), DemoData.class,null);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private List<DemoData2> data2() {
        List<DemoData2> list = new ArrayList<DemoData2>();
        for (int i = 0; i < 10; i++) {
            DemoData2 data = new DemoData2();
            data.setString1("字符串" + i);
            data.setDate1(new Date());
            data.setDoubleData1(0.56);
            list.add(data);
        }
        return list;
    }

    private List<DemoData> data() {
        List<DemoData> list = new ArrayList<DemoData>();
        for (int i = 0; i < 10; i++) {
            DemoData data = new DemoData();
            data.setString("字符串" + i);
            data.setDate(new Date());
            data.setDoubleData(0.56);
            list.add(data);
        }
        return list;
    }


    private List<List<Object>> dataList() {
        List<List<Object>> list = new ArrayList<List<Object>>();
        for (int i = 0; i < 10; i++) {
            List<Object> data = new ArrayList<Object>();
            data.add("字符串" + i);
            data.add(new Date());
            data.add(0.56);
            list.add(data);
        }
        return list;
    }
}
