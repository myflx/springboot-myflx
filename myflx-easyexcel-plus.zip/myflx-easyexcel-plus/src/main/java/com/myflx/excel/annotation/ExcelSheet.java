package com.myflx.excel.annotation;

import com.myflx.excel.ExcelSheetTemplateFactory;
import com.myflx.excel.impl.DefaultSheetTemplateFactory;

import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Inherited
public @interface ExcelSheet {
    /**
     * name of sheet
     *
     * @return string
     */
    String value();

    /**
     * type of ExcelSheetTemplateFactory
     *
     * @return class
     */
    Class<? extends ExcelSheetTemplateFactory> templateFactory() default DefaultSheetTemplateFactory.class;
}
