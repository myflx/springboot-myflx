package com.myflx.excel.holder;

import org.apache.commons.lang3.StringUtils;

/**
 * @author LuoShangLin
 */
public class CellParam {
    private String value;

    private boolean rich;

    /**
     * 是否需要值替换
     */
    private boolean replace;

    private String[] richValues;

    public CellParam(String[] richValues, boolean rich, boolean replace) {
        this.value = richValues == null ? "" : StringUtils.join(richValues, "");
        this.richValues = richValues == null ? new String[0] : richValues;
        this.rich = rich;
        this.replace = replace;
    }

    public CellParam(String[] richValues) {
        this(richValues == null ? new String[0] : richValues, false, false);
    }

    public String[] getRichValues() {
        if (richValues.length == 0) {
            return new String[richValues.length];
        }
        String[] ret = new String[richValues.length];
        System.arraycopy(richValues, 0, ret, 0, ret.length);
        return ret;
    }

    public String getValue() {
        return value;
    }

    public boolean isRich() {
        return rich;
    }

    public boolean isReplace() {
        return replace;
    }
}


