package com.myflx.excel.impl;

import com.myflx.excel.template.DefaultExcelTemplate;
import com.myflx.excel.ExcelSheetTemplate;
import com.myflx.excel.ExcelSheetTemplateFactory;
import com.myflx.excel.holder.SheetLoadHolder;

/**
 * 默认模板工厂
 *
 * @author LuoShangLin
 */
public class DefaultSheetTemplateFactory implements ExcelSheetTemplateFactory {

    /**
     * 获取模板
     *
     * @return default template
     */
    @Override
    public ExcelSheetTemplate getObject(SheetLoadHolder sheetLoadHolder) {
        final DefaultExcelTemplate standardExcelTemplate = new DefaultExcelTemplate(sheetLoadHolder.getTemplateBean());
        standardExcelTemplate.addBodyPayload(sheetLoadHolder.getBodyPayload());
        return standardExcelTemplate;
    }
}
