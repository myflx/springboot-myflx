package com.myflx.excel.util;

import com.myflx.excel.ExcelSheetTemplate;
import com.myflx.excel.holder.CellParam;

import java.util.List;

/**
 * In Memory 模式分析器
 *
 * @author LuoShangLin
 */
public class InMemoryPatternParser {
    public static final int EASY_EXCEL_IN_MEMORY_MAX_DATA = 1000;

    boolean parse(List<ExcelSheetTemplate> sheetTemplates) {
        int count = 0;
        for (ExcelSheetTemplate sheetTemplate : sheetTemplates) {
            if (sheetTemplate.getBodyPayload() != null) {
                count += sheetTemplate.getBodyPayload().size();
            }
        }
        if (count > EASY_EXCEL_IN_MEMORY_MAX_DATA) {
            return false;
        }
        boolean inMemory = false;
        for (ExcelSheetTemplate sheetTemplate : sheetTemplates) {
            final List<List<CellParam>> sourceHeadList = sheetTemplate.getSourceHeadList();
            loop:
            for (List<CellParam> cellParams : sourceHeadList) {
                for (CellParam cellParam : cellParams) {
                    if (cellParam.isRich()) {
                        inMemory = true;
                        break loop;
                    }
                }
            }
        }
        return inMemory;
    }
}
