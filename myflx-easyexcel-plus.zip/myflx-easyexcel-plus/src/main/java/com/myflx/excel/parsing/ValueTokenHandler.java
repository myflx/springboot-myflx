package com.myflx.excel.parsing;

import java.util.HashMap;
import java.util.Map;

/**
 * 占位符处理
 *
 * @author LuoShangLin
 */
public class ValueTokenHandler implements TokenHandler {
    private final Map<String, Object> payload;

    public ValueTokenHandler(Map<String, Object> payload) {
        this.payload = payload == null ? new HashMap<>(2) : payload;
    }

    @Override
    public String handleToken(String content) {
        if (payload.containsKey(content)) {
            return String.valueOf(payload.get(content));
        }
        return "";
    }
}
