package com.myflx.excel.util;

import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.write.builder.ExcelWriterSheetBuilder;
import com.alibaba.excel.write.handler.WriteHandler;
import com.myflx.excel.ExcelHandlerFactory;
import com.myflx.excel.ExcelSheetTemplate;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;

import javax.servlet.http.HttpServletResponse;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.List;

/**
 * utility class for excel
 *
 * @author LuoShangLin
 */
@Slf4j
public class FeExcels {
    private static final String DEFAULT_EXCEL_DISPOSITION = "attachment;filename=%s.xlsx";

    private static final InMemoryPatternParser IN_MEMORY_PATTERN_PARSER = new InMemoryPatternParser();

    private FeExcels() {
    }

    public static FeExcelSheetBuilder newExcel(Object template) {
        return new FeExcelSheetBuilder(template);
    }


    /**
     * @param fileName fileName
     * @param response response
     */
    public static void export(String fileName, HttpServletResponse response, ExcelSheetTemplate templateBea) {
        response.setContentType("application/vnd.ms-excel");
        response.setCharacterEncoding(StandardCharsets.UTF_8.name());
        response.setHeader("Content-disposition", String.format(DEFAULT_EXCEL_DISPOSITION, fileName));
        try {
            export(response.getOutputStream(), templateBea);
        } catch (Exception e) {
            log.error("excel export exception:", e);
        }
    }

    /**
     * export from template bean
     *
     * @param outputStream outputStream
     * @param templateBean templateBean
     */
    public static void export(OutputStream outputStream, ExcelSheetTemplate templateBean) {
        // table style
        ExcelWriterSheetBuilder excelWriterSheetBuilder = EasyExcel.write(outputStream).head(templateBean.headList()).useDefaultStyle(false).
                inMemory(IN_MEMORY_PATTERN_PARSER.parse(Collections.singletonList(templateBean))).
                sheet(templateBean.getSheetName());

        final ExcelHandlerFactory excelHandlerFactory = templateBean.getHandlerFactory();
        if (excelHandlerFactory != null) {
            final List<WriteHandler> strategyHandler = excelHandlerFactory.getStrategyHandler();
            if (CollectionUtils.isNotEmpty(strategyHandler)) {
                strategyHandler.forEach(excelWriterSheetBuilder::registerWriteHandler);
            }
        }
        excelWriterSheetBuilder.doWrite(templateBean.getBodyPayload());
    }

    /**
     * 导出多个sheet
     *
     * @param outputStream  outputStream
     * @param templateBeans templateBeans
     */
    public static void export(OutputStream outputStream, List<ExcelSheetTemplate> templateBeans) {
        ExcelWriter excelWriter = null;
        try {
            excelWriter = EasyExcel.write(outputStream).inMemory(IN_MEMORY_PATTERN_PARSER.parse(templateBeans)).build();

            for (ExcelSheetTemplate templateBean : templateBeans) {
                final ExcelWriterSheetBuilder excelWriterSheetBuilder = EasyExcel.writerSheet(templateBean.getSheetName()).head(templateBean.headList()).useDefaultStyle(false);

                final ExcelHandlerFactory excelHandlerFactory = templateBean.getHandlerFactory();
                if (excelHandlerFactory != null) {
                    final List<WriteHandler> strategyHandler = excelHandlerFactory.getStrategyHandler();
                    if (CollectionUtils.isNotEmpty(strategyHandler)) {
                        strategyHandler.forEach(excelWriterSheetBuilder::registerWriteHandler);
                    }
                }
                excelWriter.write(templateBean.getBodyPayload(), excelWriterSheetBuilder.build());
            }
        } catch (Exception e) {
            log.error("导出异常：", e);
        } finally {
            if (excelWriter != null) {
                excelWriter.finish();
            }
        }

    }

}
