package com.myflx.excel;

import java.util.List;
import java.util.Map;

/**
 * payload of excel body
 *
 * @author LuoShangLin
 */
public interface BodyPayload {


    /**
     * body payload
     *
     * @return list
     */
    List<Object> getBodyPayload();
}
