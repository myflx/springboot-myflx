package com.myflx.excel;

import com.myflx.excel.holder.SheetLoadHolder;

/**
 * @author LuoShangLin
 */
public interface ExcelSheetTemplateFactory {

    /**
     * 获取模板
     * 下次优化项是通过赤化技术优化模板对象的获取提高性能
     *
     * @param sheetLoadHolder sheetLoadHolder
     * @return template
     */
    ExcelSheetTemplate getObject(SheetLoadHolder sheetLoadHolder);
}
