package com.myflx.excel.template;

import com.myflx.excel.ExcelHandlerFactory;
import com.myflx.excel.ExcelSheetTemplate;
import com.myflx.excel.holder.CellParam;
import com.myflx.excel.holder.ExcelTemplateHolder;
import lombok.Getter;
import lombok.Setter;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.springframework.util.Assert;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * abstract excel template
 *
 * @author LuoShangLin
 */
public abstract class AbstractExcelTemplate implements ExcelSheetTemplate {
    private boolean autoHeight;
    private float headHeight;
    private float bodyHeight;
    private final short headFontHeightInPoints;
    private final short bodyFontHeightInPoints;
    private final Object target;
    private ExcelHandlerFactory handlerFactory;
    private Set<Integer> rowBold = new HashSet<>(4);
    private final Map<Integer, IndexedColors> rowBgColorMap = new ConcurrentHashMap<>(8);
    private final Map<Integer, HorizontalAlignment> rowHorizontalAlignmentMap = new ConcurrentHashMap<>(8);

    @Getter
    @Setter
    private List<Object> bodyPayload;
    private final AtomicBoolean ctl = new AtomicBoolean(false);
    private final Map<String, Object> headPayLoad = new HashMap<>(16);

    static {
        ExcelTemplateHolder.init(Object.class);
    }

    public AbstractExcelTemplate(Object target) {
        Assert.notNull(target, "template bean must not be null!");
        this.autoHeight = true;
        this.headHeight = 2f;
        this.bodyHeight = 1.5f;
        this.target = target;
        this.headFontHeightInPoints = 14;
        this.bodyFontHeightInPoints = 12;
        ExcelTemplateHolder.init(getTargetClass());
        this.addRowBgColor(getSourceHeadList().size() - 1, IndexedColors.RED);
    }

    private Class<?> getTargetClass() {
        return target.getClass();
    }

    public void addBodyPayload(List<Object> bodyPayload) {
        if (this.bodyPayload == null) {
            this.bodyPayload = new ArrayList<>();
        }
        if (bodyPayload != null) {
            this.bodyPayload.addAll(bodyPayload);
        }
    }

    /**
     * head payload
     *
     * @return map
     */
    @Override
    public Map<String, Object> getHeadPayload() {
        if (ctl.get()) {
            return headPayLoad;
        }
        synchronized (ctl) {
            //double check
            if (!ctl.get()) {
                Map<String, Object> beanMap = ExcelTemplateHolder.getHeadPayLoad(target);
                headPayLoad.putAll(beanMap);
                ctl.set(true);
            }
        }
        return headPayLoad;
    }

    /**
     * 返回目标头部列表
     *
     * @return list
     */
    @Override
    public List<List<String>> headList() {
        return ExcelTemplateHolder.getHeadList(this.getTargetClass());
    }


    @Override
    public List<List<CellParam>> getSourceHeadList() {
        return ExcelTemplateHolder.getSourceHeadList(this.getTargetClass());
    }

    /**
     * 返回sheet名称
     *
     * @return str
     */
    @Override
    public String getSheetName() {
        return ExcelTemplateHolder.getSheetName(this.getTargetClass());
    }

    /**
     * 模板关联的处理器工厂
     *
     * @return ExcelHandlerFactory
     */
    @Override
    public ExcelHandlerFactory getHandlerFactory() {
        return handlerFactory;
    }

    /**
     * 设置
     *
     * @param handlerFactory handlerFactory
     */
    @Override
    public void setHandlerFactory(ExcelHandlerFactory handlerFactory) {
        this.handlerFactory = handlerFactory;
    }

    /**
     * 添加行
     *
     * @param rowIndex 行索引
     * @param colors   色值
     */
    @Override
    public void addRowBgColor(Integer rowIndex, IndexedColors colors) {
        rowBgColorMap.put(rowIndex, colors);
    }

    /**
     * 单行颜色
     *
     * @return map
     */
    @Override
    public Map<Integer, IndexedColors> rowBgColor() {
        return rowBgColorMap;
    }

    /**
     * 行对齐方式
     *
     * @return map
     */
    @Override
    public Map<Integer, HorizontalAlignment> rowHorizontalAlignment() {
        return rowHorizontalAlignmentMap;
    }

    /**
     * 添加单行对齐方式
     *
     * @param rowIndex  行索引
     * @param alignment 对齐方式
     */
    @Override
    public void addRowHorizontalAlignment(Integer rowIndex, HorizontalAlignment alignment) {
        rowHorizontalAlignmentMap.put(rowIndex, alignment);
    }

    /**
     * Auto Height
     *
     * @return Boolean
     */
    @Override
    public boolean isAutoHeight() {
        return autoHeight;
    }

    /**
     * Head Height
     *
     * @return float
     */
    @Override
    public float getHeadHeight() {
        return headHeight;
    }

    /**
     * body Height
     *
     * @return float
     */
    @Override
    public float getBodyHeight() {
        return bodyHeight;
    }

    /**
     * 行加粗
     *
     * @return map
     */
    @Override
    public Set<Integer> rowBold() {
        return rowBold;
    }

    /**
     * 行加粗
     *
     * @param rowIndex 行索引
     */
    @Override
    public void addRowBold(Integer rowIndex) {
        rowBold.add(rowIndex);
    }

    /**
     * 内容字体高度
     *
     * @return short
     */
    @Override
    public Short bodyFontHeightInPoints() {
        return bodyFontHeightInPoints;
    }

    /**
     * 头部字体高度
     *
     * @return short
     */
    @Override
    public Short headFontHeightInPoints() {
        return headFontHeightInPoints;
    }
}
