package com.myflx.excel.handler;

import com.myflx.excel.HeadPayload;
import com.myflx.excel.parsing.GenericTokenParser;
import com.myflx.excel.parsing.ValueTokenHandler;

import java.util.Map;

/**
 * @author LuoShangLin
 */

public class DefaultExcelHeadPayLoadHandler extends AbstractPayloadHandler {


    public DefaultExcelHeadPayLoadHandler(HeadPayload templateBean) {
        super(templateBean);
    }

    /**
     * get token replace handler
     *
     * @param headPayload headPayload
     * @return GenericTokenParser
     */
    @Override
    protected GenericTokenParser getTokenParser(Map<String, Object> headPayload) {
        return new GenericTokenParser("#{", "}", new ValueTokenHandler(headPayload));
    }
}

