package com.myflx.excel.template;

import com.myflx.excel.annotation.ExcelSheet;
import com.myflx.excel.annotation.FeRow;
import com.myflx.excel.annotation.HeadPayload;
import lombok.Data;

/**
 * 模板注解
 *
 * @author LuoShangLin
 */
@Data
@ExcelSheet("sheet名称2")
@FeRow({"02第一列", "#{dateTime}", "02第三列", "02第4列"})
public class DemoTemplate01 {

    @HeadPayload
    private String dateTime;

    @HeadPayload
    private String supplierName;

    @HeadPayload
    private DemoTemplate01 demoVO;
}
