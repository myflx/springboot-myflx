package com.myflx.excel;

import com.alibaba.excel.write.handler.WriteHandler;
import com.alibaba.excel.write.style.column.AbstractColumnWidthStyleStrategy;
import com.alibaba.excel.write.style.row.AbstractRowHeightStyleStrategy;
import com.myflx.excel.handler.AbstractPayloadHandler;
import com.myflx.excel.handler.AbstractWorkbookHandler;

import java.util.List;

/**
 * @author LuoShangLin
 */
public interface ExcelHandlerFactory {

    /**
     * 样式处理器
     *
     * @return handler
     */
    WriteHandler styleHandler();


    /**
     * widthHandler
     *
     * @return handler
     */
    AbstractColumnWidthStyleStrategy widthHandler();

    /**
     * heightHandler
     *
     * @param templateBean templateBean
     * @return sheet
     */
    AbstractRowHeightStyleStrategy heightHandler(ExcelSheetTemplate templateBean);


    /**
     * bodyPayload
     *
     * @param bodyPayload bodyPayload
     * @return handler
     */
    AbstractPayloadHandler bodyPayloadHandler(BodyPayload bodyPayload);


    /**
     * excel monitor handler
     *
     * @return handler
     */
    AbstractWorkbookHandler excelMonitorHandler();

    /**
     * get all excel handler
     *
     * @return list
     */
    List<WriteHandler> getStrategyHandler();
}
