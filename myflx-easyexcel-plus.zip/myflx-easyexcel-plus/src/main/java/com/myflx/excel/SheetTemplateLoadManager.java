package com.myflx.excel;

/**
 * sheet template data load manager
 *
 * @author LuoShangLin
 */
public interface SheetTemplateLoadManager {
    /**
     * return true if data is loaded to sheet template
     * else false
     *
     * @return Boolean
     */
    boolean isLoad();

    /**
     * load data
     */
    void load();

    /**
     * unload data
     */
    void unload();
}
