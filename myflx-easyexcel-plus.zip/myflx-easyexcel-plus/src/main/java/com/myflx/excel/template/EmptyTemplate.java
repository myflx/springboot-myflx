package com.myflx.excel.template;

import lombok.Data;

/**
 * 空模板
 *
 * @author LuoShangLin
 */
@Data
public class EmptyTemplate {

}
