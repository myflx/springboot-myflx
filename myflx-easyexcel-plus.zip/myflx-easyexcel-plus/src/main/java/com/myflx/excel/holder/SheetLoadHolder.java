package com.myflx.excel.holder;

import com.myflx.excel.template.EmptyTemplate;

import java.util.List;

/**
 * sheet load obj
 *
 * @author LuoShangLin
 */
public class SheetLoadHolder {
    private static final EmptyTemplate SHARED = new EmptyTemplate();

    private final Object templateBean;

    private List<Object> bodyPayload;

    public SheetLoadHolder(Object templateBean) {
        this.templateBean = templateBean == null ? SHARED : templateBean;
    }

    public List<Object> getBodyPayload() {
        return bodyPayload;
    }

    public void setBodyPayload(List<Object> bodyPayload) {
        this.bodyPayload = bodyPayload;
    }

    public Object getTemplateBean() {
        return templateBean;
    }
}
