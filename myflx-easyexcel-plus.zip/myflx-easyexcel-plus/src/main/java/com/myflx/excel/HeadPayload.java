package com.myflx.excel;

import java.util.Map;

/**
 * payload of excel head
 *
 * @author LuoShangLin
 */
public interface HeadPayload {
    /**
     * head payload
     *
     * @return map
     */
    Map<String, Object> getHeadPayload();
}
