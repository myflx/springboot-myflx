package com.myflx.excel.template;

import com.myflx.excel.annotation.ExcelSheet;
import com.myflx.excel.annotation.HeadPayload;
import com.myflx.excel.annotation.RichCell;
import com.myflx.excel.annotation.RichRow;
import lombok.Data;

/**
 * 模板注解
 *
 * @author LuoShangLin
 */
@Data
@ExcelSheet("sheet名称")
@RichRow({@RichCell(value = {"#{dateTime}个人信息收集模板"})})
@RichRow({@RichCell({"*", "姓名", "\n姓名为必填项不能为空"}), @RichCell({"*", "年龄", "\n年龄必填"}), @RichCell({"*", "性别", "\n性别必填"}), @RichCell({"身高"})})
@RichRow({@RichCell({"第三行姓名说明"}), @RichCell({"第三行年龄说明1"}), @RichCell({"第三行年龄说明2"}), @RichCell({"第三行年龄说明3"})})
public class DemoTemplate {

    @HeadPayload
    private String dateTime;

    @HeadPayload
    private String supplierName;

    @HeadPayload
    private DemoTemplate demoVO;
}
