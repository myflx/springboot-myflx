package com.myflx.excel.holder;

import com.myflx.excel.ExcelSheetTemplateFactory;
import com.myflx.excel.impl.DefaultSheetTemplateFactory;
import com.myflx.excel.parsing.ExcelSheetParser;
import lombok.extern.slf4j.Slf4j;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author LuoShangLin
 */
@Slf4j
public class ExcelTemplateHolder {
    private ExcelTemplateHolder() {
        //nothing
    }

    private static final Map<String, ExcelTemplateParam> TEMPLATE_CACHE_MAP = new ConcurrentHashMap<>();

    private static final Map<String, ExcelSheetTemplateFactory> TEMPLATE_FACTORY_MAP = new ConcurrentHashMap<>();

    private static final ExcelSheetParser HEAD_PARSER = new ExcelSheetParser();

    /**
     * get excel head list
     *
     * @param templateClass aClass
     * @return List
     */
    public static List<List<String>> getHeadList(Class<?> templateClass) {
        return TEMPLATE_CACHE_MAP.get(templateClass.toString()).getHeadList();
    }

    public static List<List<CellParam>> getSourceHeadList(Class<?> templateClass) {
        return TEMPLATE_CACHE_MAP.get(templateClass.toString()).getSourceHeadCellList();
    }

    public static synchronized void init(Class<?> templateClass) {
        //twice check
        final String cacheKey = templateClass.toString();
        if (TEMPLATE_CACHE_MAP.get(cacheKey) != null) {
            return;
        }
        //parseHead head and cache
        TEMPLATE_CACHE_MAP.put(cacheKey, HEAD_PARSER.parseHead(templateClass));
    }

    /**
     * getHeadPayLoad
     *
     * @param abstractExcelTemplate abstractExcelTemplate
     * @return list
     */
    public static Map<String, Object> getHeadPayLoad(Object abstractExcelTemplate) {
        return HEAD_PARSER.parseHeadPayload(abstractExcelTemplate);
    }

    /**
     * 返回sheet名称
     *
     * @param templateClass templateClass
     * @return list
     */
    public static String getSheetName(Class<?> templateClass) {
        return TEMPLATE_CACHE_MAP.get(templateClass.toString()).getSheetName();
    }

    public static ExcelSheetTemplateFactory getSheetTemplateFactory(Object templateBean) {
        final Class<?> clazz = templateBean.getClass();
        final String canonicalName = clazz.getCanonicalName();
        ExcelSheetTemplateFactory excelSheetTemplateFactory = TEMPLATE_FACTORY_MAP.get(canonicalName);
        if (excelSheetTemplateFactory == null) {
            synchronized (clazz) {
                excelSheetTemplateFactory = TEMPLATE_FACTORY_MAP.get(canonicalName);
                //double check
                if (excelSheetTemplateFactory == null) {
                    try {
                        TEMPLATE_FACTORY_MAP.put(canonicalName, HEAD_PARSER.parseTemplateFactory(templateBean.getClass()));
                    } catch (Exception e) {
                        log.error("sheet template factory parse exception(use DefaultSheetTemplateFactory):", e);
                        TEMPLATE_FACTORY_MAP.put(canonicalName, new DefaultSheetTemplateFactory());
                    }
                }
            }
        }
        return TEMPLATE_FACTORY_MAP.get(canonicalName);
    }
}
