package com.myflx.excel.parsing;

import java.util.concurrent.atomic.AtomicBoolean;

/**
 * 占位符存在性分析
 *
 * @author LuoShangLin
 */
public class ReplaceAnalysisTokenHandler implements TokenHandler {
    private AtomicBoolean exist = new AtomicBoolean(false);

    @Override
    public String handleToken(String content) {
        exist.set(true);
        return content;
    }

    public boolean isExist() {
        return exist.get();
    }
}
