package com.myflx.excel.handler;

import com.alibaba.excel.metadata.Head;
import com.alibaba.excel.util.StyleUtil;
import com.alibaba.excel.write.metadata.style.WriteCellStyle;
import com.alibaba.excel.write.metadata.style.WriteFont;
import com.alibaba.excel.write.style.AbstractCellStyleStrategy;
import com.myflx.excel.ExcelSheetTemplate;
import com.myflx.excel.holder.CellParam;
import com.myflx.excel.parsing.GenericTokenParser;
import com.myflx.excel.parsing.ValueTokenHandler;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Workbook;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * @author LuoShangLin
 */
@Slf4j
public class CellStyleSheetWriteHandler extends AbstractCellStyleStrategy {

    private Workbook workbook;
    private final ExcelSheetTemplate excelSheetTemplate;
    private final GenericTokenParser parser;
    private final RichTextHandler textHandler;

    public CellStyleSheetWriteHandler(ExcelSheetTemplate excelSheetTemplate) {
        this.excelSheetTemplate = excelSheetTemplate;
        this.parser = new GenericTokenParser("#{", "}", new ValueTokenHandler(excelSheetTemplate.getHeadPayload()));
        this.textHandler = new RichTextHandler(excelSheetTemplate);
    }

    @Override
    protected void initCellStyle(Workbook workbook) {
        this.workbook = workbook;
        textHandler.initCellStyle(workbook);
    }


    @Override
    protected void setHeadCellStyle(Cell cell, Head head, Integer relativeRowIndex) {
        WriteCellStyle headCellStyle = new WriteCellStyle();
        final Map<Integer, IndexedColors> integerIndexedColorsMap = excelSheetTemplate.rowBgColor();
        final Map<Integer, HorizontalAlignment> integerHorizontalAlignmentMap = excelSheetTemplate.rowHorizontalAlignment();
        final Set<Integer> integers = excelSheetTemplate.rowBold();
        final IndexedColors orDefault = integerIndexedColorsMap.getOrDefault(relativeRowIndex, IndexedColors.WHITE);
        final HorizontalAlignment horizontalAlignment = integerHorizontalAlignmentMap.getOrDefault(relativeRowIndex, HorizontalAlignment.CENTER);
        headCellStyle.setFillForegroundColor(orDefault.getIndex());
        headCellStyle.setHorizontalAlignment(horizontalAlignment);
        WriteFont headFont = new WriteFont();
        headFont.setFontHeightInPoints(excelSheetTemplate.headFontHeightInPoints());
        headFont.setBold(integers.contains(relativeRowIndex));
        headCellStyle.setWriteFont(headFont);
        CellStyle cellStyle = StyleUtil.buildHeadCellStyle(workbook, headCellStyle);
        cell.setCellStyle(cellStyle);
        final List<List<CellParam>> sourceHeadList = excelSheetTemplate.getSourceHeadList();

        final List<CellParam> cellParams = sourceHeadList.get(relativeRowIndex);
        final int columnIndex = cell.getColumnIndex();
        final CellParam cellParam = cellParams.get(columnIndex < cellParams.size() ? columnIndex : cellParams.size() - 1);
        final String[] richValues = cellParam.getRichValues();

        if (cellParam.isReplace()) {
            for (int i = 0; i < richValues.length; i++) {
                richValues[i] = parser.parse(richValues[i]);
            }
        }
        if (cellParam.isRich()) {
            textHandler.headHandleStyle(cell, relativeRowIndex, richValues);
        } else {
            cell.setCellValue(StringUtils.join(richValues, ""));
        }
    }


    @Override
    protected void setContentCellStyle(Cell cell, Head head, Integer relativeRowIndex) {
        int abs = relativeRowIndex + excelSheetTemplate.getSourceHeadList().size();
        WriteCellStyle headCellStyle = new WriteCellStyle();
        final Set<Integer> integers = excelSheetTemplate.rowBold();
        final Map<Integer, IndexedColors> integerIndexedColorsMap = excelSheetTemplate.rowBgColor();
        final Map<Integer, HorizontalAlignment> integerHorizontalAlignmentMap = excelSheetTemplate.rowHorizontalAlignment();
        final IndexedColors orDefault = integerIndexedColorsMap.getOrDefault(abs, IndexedColors.WHITE);
        final HorizontalAlignment horizontalAlignment = integerHorizontalAlignmentMap.getOrDefault(abs, HorizontalAlignment.CENTER);
        headCellStyle.setFillForegroundColor(orDefault.getIndex());
        headCellStyle.setHorizontalAlignment(horizontalAlignment);
        WriteFont headFont = new WriteFont();
        headFont.setFontHeightInPoints(excelSheetTemplate.bodyFontHeightInPoints());
        headFont.setBold(integers.contains(abs));
        headCellStyle.setWriteFont(headFont);
        CellStyle cellStyle = StyleUtil.buildHeadCellStyle(workbook, headCellStyle);
        cell.setCellStyle(cellStyle);
    }
}