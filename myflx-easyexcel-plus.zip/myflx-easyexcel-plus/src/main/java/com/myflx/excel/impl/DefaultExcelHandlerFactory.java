package com.myflx.excel.impl;

import com.alibaba.excel.write.handler.WriteHandler;
import com.alibaba.excel.write.style.column.AbstractColumnWidthStyleStrategy;
import com.alibaba.excel.write.style.column.LongestMatchColumnWidthStyleStrategy;
import com.alibaba.excel.write.style.row.AbstractRowHeightStyleStrategy;
import com.myflx.excel.BodyPayload;
import com.myflx.excel.ExcelHandlerFactory;
import com.myflx.excel.ExcelSheetTemplate;
import com.myflx.excel.handler.AbstractPayloadHandler;
import com.myflx.excel.handler.AbstractWorkbookHandler;
import com.myflx.excel.handler.CellStyleSheetWriteHandler;
import com.myflx.excel.handler.DefaultWorkbookWriteHandler;
import com.myflx.excel.handler.HeightHandler;

import java.util.ArrayList;
import java.util.List;

/**
 * @author LuoShangLin
 */
public class DefaultExcelHandlerFactory implements ExcelHandlerFactory {
    private static final AbstractColumnWidthStyleStrategy AUTO_WIDTH_HANDLER = new LongestMatchColumnWidthStyleStrategy();
    private static final AbstractWorkbookHandler EXCEL_MONITOR_HANDLER = new DefaultWorkbookWriteHandler();

    private final ExcelSheetTemplate excelSheetTemplate;

    public DefaultExcelHandlerFactory(ExcelSheetTemplate excelSheetTemplate) {
        this.excelSheetTemplate = excelSheetTemplate;
    }

    /**
     * 样式处理器
     *
     * @return handler
     */
    @Override
    public WriteHandler styleHandler() {
        return new CellStyleSheetWriteHandler(excelSheetTemplate);
    }

    /**
     * widthHandler
     *
     * @return handler
     */
    @Override
    public AbstractColumnWidthStyleStrategy widthHandler() {
        return AUTO_WIDTH_HANDLER;
    }

    /**
     * @param templateBean templateBean
     * @return sheet
     */
    @Override
    public AbstractRowHeightStyleStrategy heightHandler(ExcelSheetTemplate templateBean) {
        return new HeightHandler(templateBean);
    }


    /**
     * bodyPayload
     * 暂无实现
     *
     * @param bodyPayload bodyPayload
     * @return handler
     */
    @Override
    public AbstractPayloadHandler bodyPayloadHandler(BodyPayload bodyPayload) {
        return null;
    }


    /**
     * excel monitor handler
     *
     * @return handler
     */
    @Override
    public AbstractWorkbookHandler excelMonitorHandler() {
        return EXCEL_MONITOR_HANDLER;
    }

    /**
     * get all excel handler
     *
     * @return list
     */
    @Override
    public final List<WriteHandler> getStrategyHandler() {
        List<WriteHandler> list = new ArrayList<>();
        //body payloadHandler
        final WriteHandler bodyPayloadHandler = bodyPayloadHandler(excelSheetTemplate);
        if (bodyPayloadHandler != null) {
            list.add(bodyPayloadHandler);
        }

        //width handler
        final WriteHandler writeHandler = widthHandler();
        if (writeHandler != null) {
            list.add(writeHandler);
        }

        //height handler
        final WriteHandler heightHandler = heightHandler(excelSheetTemplate);
        if (heightHandler != null) {
            list.add(heightHandler);
        }

        //style handler
        final WriteHandler styleHandler = styleHandler();
        if (styleHandler != null) {
            list.add(styleHandler);
        }

        //excel Monitor Handler
        final WriteHandler excelMonitorHandler = excelMonitorHandler();
        if (excelMonitorHandler != null) {
            list.add(excelMonitorHandler);
        }
        return list;
    }
}
