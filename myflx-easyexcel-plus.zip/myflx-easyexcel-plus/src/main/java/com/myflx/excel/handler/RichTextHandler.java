package com.myflx.excel.handler;

import com.myflx.excel.ExcelSheetTemplate;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.RichTextString;
import org.apache.poi.ss.usermodel.Workbook;

/**
 * @author LuoShangLin
 */
public class RichTextHandler {
    private final ExcelSheetTemplate excelSheetTemplate;
    private Workbook workbook;

    public RichTextHandler(ExcelSheetTemplate excelSheetTemplate) {
        this.excelSheetTemplate = excelSheetTemplate;
    }

    protected void initCellStyle(Workbook workbook) {
        this.workbook = workbook;
    }

    public void headHandleStyle(Cell cell, Integer relativeRowIndex, String[] richValues) {
        CreationHelper creationHelper = workbook.getCreationHelper();
        RichTextString richTextString = creationHelper.createRichTextString(StringUtils.join(richValues, ""));
        int pre = 0;
        for (int i = 0; i < richValues.length; i++) {
            Font font = workbook.createFont();
            String value = richValues[i];
            final Font fontAt = workbook.getFontAt(relativeRowIndex);
            if (i == 0) {
                font.setColor(IndexedColors.RED1.getIndex());
            } else if (i == 1) {
                font.setFontHeightInPoints(excelSheetTemplate.headFontHeightInPoints());
            } else if (i == 2) {
                font.setColor(IndexedColors.RED1.getIndex());
                font.setFontHeightInPoints((short) (excelSheetTemplate.headFontHeightInPoints() - 3));
            } else {
                font = fontAt;
            }
            richTextString.applyFont(pre, pre + value.length(), font);
            pre += value.length();
        }
        cell.setCellValue(richTextString);
    }
}
