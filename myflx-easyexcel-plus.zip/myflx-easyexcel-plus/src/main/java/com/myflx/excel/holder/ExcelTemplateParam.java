package com.myflx.excel.holder;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author LuoShangLin
 */
public class ExcelTemplateParam {
    private final String sheetName;
    private final List<List<CellParam>> headCellList;
    private final List<List<CellParam>> sourceHeadCellList;
    private List<List<String>> headList;

    public ExcelTemplateParam(String sheetName, List<List<CellParam>> headCellList, List<List<CellParam>> sourceHeadCellList) {
        this.sheetName = sheetName;
        this.headCellList = headCellList == null ? new ArrayList<>() : headCellList;
        this.sourceHeadCellList = sourceHeadCellList;
        this.headList = new ArrayList<>();
        for (List<CellParam> excelCells : this.headCellList) {
            this.headList.add(excelCells.stream().map(CellParam::getValue).collect(Collectors.toList()));
        }
    }


    public List<List<String>> getHeadList() {
        return headList;
    }

    public List<List<CellParam>> getSourceHeadCellList() {
        return sourceHeadCellList;
    }

    public List<List<CellParam>> getHeadCellList() {
        return headCellList;
    }

    public String getSheetName() {
        return sheetName;
    }
}
