package com.myflx.excel.handler;

import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.Workbook;

/**
 * @author LuoShangLin
 */
@Slf4j
public class DefaultWorkbookWriteHandler extends AbstractWorkbookHandler {
    private long st;

    /**
     * excel 创建完成之后的操作
     *
     * @param workbook excel obj
     */
    @Override
    public void afterExcelCreate(Workbook workbook) {
        st = System.currentTimeMillis();
        log.debug("file create timestamp:{}", st);
    }

    /**
     * 流刷新之前的查找
     *
     * @param workbook workbook
     */
    @Override
    public void beforeFlush(Workbook workbook) {
        long et = System.currentTimeMillis();
        log.debug("file flush timestamp:{},total cost:{}", et, et - st);
    }
}
