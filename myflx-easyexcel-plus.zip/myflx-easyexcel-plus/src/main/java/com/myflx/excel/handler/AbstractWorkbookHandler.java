package com.myflx.excel.handler;

import com.alibaba.excel.write.metadata.holder.WriteWorkbookHolder;
import org.apache.poi.ss.usermodel.Workbook;

/**
 * Abstract workbook handler
 * @author LuoShangLin
 */
public abstract class AbstractWorkbookHandler extends com.alibaba.excel.write.handler.AbstractWorkbookWriteHandler {
    private Workbook workbook;

    @Override
    public void afterWorkbookCreate(WriteWorkbookHolder writeWorkbookHolder) {
        this.workbook = writeWorkbookHolder.getWorkbook();
        afterExcelCreate(this.workbook);
    }

    @Override
    public void afterWorkbookDispose(WriteWorkbookHolder writeWorkbookHolder) {
        beforeFlush(this.workbook);
    }

    /**
     * excel 创建完成之后的操作
     *
     * @param workbook excel obj
     */
    public abstract void afterExcelCreate(Workbook workbook);

    /**
     * 流刷新之前的查找
     *
     * @param workbook workbook
     */
    public abstract void beforeFlush(Workbook workbook);
}
