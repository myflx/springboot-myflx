package com.myflx.excel.handler;

import com.alibaba.excel.metadata.CellData;
import com.alibaba.excel.metadata.Head;
import com.alibaba.excel.write.handler.AbstractCellWriteHandler;
import com.alibaba.excel.write.metadata.holder.WriteSheetHolder;
import com.alibaba.excel.write.metadata.holder.WriteTableHolder;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.RichTextString;
import org.apache.poi.ss.usermodel.Row;

import java.util.List;

/**
 * @Description TODO
 * @Author LuoShangLin
 * @Date 2021/1/25 17:57
 * @Since V2.13.0
 */
public class CellCreateHandler extends AbstractCellWriteHandler {

    @Override
    public void beforeCellCreate(WriteSheetHolder writeSheetHolder, WriteTableHolder writeTableHolder, Row row, Head head, Integer columnIndex, Integer relativeRowIndex, Boolean isHead) {

        /*final Workbook workbook = writeSheetHolder.getSheet().getWorkbook();
        CreationHelper creationHelper = workbook.getCreationHelper();

        Font font = workbook.createFont(); // default font
        Font fontBold = workbook.createFont();
        fontBold.setBold(true);
        fontBold.setColor(IndexedColors.RED1.getIndex());

        String text = "HellomynameisThad";
        String word = "name";

        RichTextString richTextString = creationHelper.createRichTextString(text);
        int startIndex = text.indexOf(word);
        int endIndex = startIndex + word.length();
        richTextString.applyFont(startIndex, endIndex, fontBold);


        writeSheetHolder.getSheet().createRow(10).createCell(0).setCellValue(richTextString);*/
    }

    @Override
    public void afterCellDispose(WriteSheetHolder writeSheetHolder, WriteTableHolder writeTableHolder, List<CellData> cellDataList, Cell cell, Head head, Integer relativeRowIndex, Boolean isHead) {
        if (!isHead) {
            return;
        }
        /*CreationHelper creationHelper = writeSheetHolder.getSheet().getWorkbook().getCreationHelper();
        Font fontBold = writeSheetHolder.getSheet().getWorkbook().createFont();
        fontBold.setBold(true);
        fontBold.setColor(IndexedColors.RED1.getIndex());
        RichTextString richTextString = creationHelper.createRichTextString(cell.getStringCellValue());
        richTextString.applyFont(0, 1, fontBold);
        cell.setCellValue(richTextString);*/


        CreationHelper creationHelper = writeSheetHolder.getSheet().getWorkbook().getCreationHelper();
        Font fontBold = writeSheetHolder.getSheet().getWorkbook().createFont();
        fontBold.setBold(true);
        fontBold.setColor(IndexedColors.RED1.getIndex());
        String text = "HellomynameisThad";
        String word = "name";
        RichTextString richTextString = creationHelper.createRichTextString(text);
        int startIndex = text.indexOf(word);
        int endIndex = startIndex + word.length();
        richTextString.applyFont(startIndex, endIndex, fontBold);
        cell.setCellValue(richTextString);

        CellStyle cellStyle = writeSheetHolder.getSheet().getWorkbook().createCellStyle();
        cellStyle.setWrapText(true);
        cell.setCellStyle(cellStyle);
    }
}
