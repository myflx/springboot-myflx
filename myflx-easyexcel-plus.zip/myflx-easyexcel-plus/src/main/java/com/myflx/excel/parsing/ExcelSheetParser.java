package com.myflx.excel.parsing;

import com.myflx.excel.ExcelSheetTemplateFactory;
import com.myflx.excel.annotation.ExcelHead;
import com.myflx.excel.annotation.ExcelSheet;
import com.myflx.excel.annotation.FeExcelHead;
import com.myflx.excel.annotation.FeRow;
import com.myflx.excel.annotation.HeadPayload;
import com.myflx.excel.annotation.RichCell;
import com.myflx.excel.annotation.RichRow;
import com.myflx.excel.holder.CellParam;
import com.myflx.excel.holder.ExcelTemplateParam;
import com.myflx.excel.impl.DefaultSheetTemplateFactory;
import net.sf.cglib.beans.BeanMap;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.core.annotation.AnnotationUtils;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * head parser
 *
 * @author LuoShangLin
 */
public class ExcelSheetParser {
    private static final ExcelTemplateParam NULL_PARAM = new ExcelTemplateParam(null, new ArrayList<>(), new ArrayList<>());

    /**
     * parseHead template class to java bean
     *
     * @param templateClass templateClass
     * @return obj
     */
    public ExcelTemplateParam parseHead(Class<?> templateClass) {
        final ExcelHead annotation = AnnotationUtils.findAnnotation(templateClass, ExcelHead.class);
        RichRow[] value = null;
        if (annotation != null && !ArrayUtils.isEmpty(annotation.value())) {
            value = annotation.value();
        } else if (templateClass.isAnnotationPresent(RichRow.class)) {
            value = new RichRow[]{AnnotationUtils.findAnnotation(templateClass, RichRow.class)};
        }
        if (value == null) {
            return parseCommonHead(templateClass);
        }
        GenericTokenParser parser = new GenericTokenParser("#{", "}");
        List<List<CellParam>> sourceHeadCellList = new ArrayList<>();
        for (RichRow headRow : value) {
            List<CellParam> cellList = new ArrayList<>();
            final RichCell[] richCells = headRow.value();
            if (!ArrayUtils.isEmpty(richCells)) {
                for (RichCell richCell : richCells) {
                    final String[] richValues = richCell.value();
                    cellList.add(new CellParam(richValues, richValues.length > 1, existPlaceHolder(parser, richValues)));
                }
            }
            sourceHeadCellList.add(cellList);
        }

        //parse sheet name
        String sheetName = null;
        if (templateClass.isAnnotationPresent(ExcelSheet.class)) {
            sheetName = templateClass.getAnnotation(ExcelSheet.class).value();
        }
        final List<List<CellParam>> headCellList = this.reverse(sourceHeadCellList);
        return new ExcelTemplateParam(sheetName, headCellList, sourceHeadCellList);
    }

    private boolean existPlaceHolder(GenericTokenParser parser, String[] richValues) {
        boolean exist = false;
        for (String richValue : richValues) {
            final ReplaceAnalysisTokenHandler tokenHandler = new ReplaceAnalysisTokenHandler();
            parser.setHandler(tokenHandler);
            if (StringUtils.isNotBlank(parser.parse(richValue)) && tokenHandler.isExist()) {
                exist = true;
            }
        }
        return exist;
    }

    private ExcelTemplateParam parseCommonHead(Class<?> templateClass) {
        final FeExcelHead annotation = AnnotationUtils.findAnnotation(templateClass, FeExcelHead.class);
        FeRow[] value = null;
        if (annotation != null && !ArrayUtils.isEmpty(annotation.value())) {
            value = annotation.value();
        } else if (templateClass.isAnnotationPresent(FeRow.class)) {
            value = new FeRow[]{AnnotationUtils.findAnnotation(templateClass, FeRow.class)};
        }
        if (value == null) {
            return NULL_PARAM;
        }
        GenericTokenParser parser = new GenericTokenParser("#{", "}");
        List<List<CellParam>> sourceHeadCellList = new ArrayList<>();
        for (FeRow headRow : value) {
            List<CellParam> cellList = new ArrayList<>();
            final String[] values = headRow.value();
            if (!ArrayUtils.isEmpty(values)) {
                for (String v : values) {
                    String[] vs = new String[]{v};
                    cellList.add(new CellParam(vs, false, existPlaceHolder(parser, vs)));
                }
            }
            sourceHeadCellList.add(cellList);
        }

        //parse sheet name
        String sheetName = null;
        if (templateClass.isAnnotationPresent(ExcelSheet.class)) {
            sheetName = templateClass.getAnnotation(ExcelSheet.class).value();
        }
        final List<List<CellParam>> headCellList = this.reverse(sourceHeadCellList);
        return new ExcelTemplateParam(sheetName, headCellList, sourceHeadCellList);
    }

    /**
     * 行列翻转
     *
     * @param headCellList headCellList
     */
    private List<List<CellParam>> reverse(List<List<CellParam>> headCellList) {
        List<List<CellParam>> reverseList = new ArrayList<>();
        int maxColumnSize = 0;
        for (List<CellParam> cellList : headCellList) {
            maxColumnSize = Math.max(maxColumnSize, cellList.size());
        }
        List<List<CellParam>> sourceList = new ArrayList<>(headCellList);
        for (int i = 0; i < maxColumnSize; i++) {
            List<CellParam> columnList = new ArrayList<>();
            for (List<CellParam> cellList : sourceList) {
                columnList.add(cellList.size() > i ? cellList.get(i) : cellList.get(cellList.size() - 1));
            }
            reverseList.add(columnList);
        }
        return reverseList;
    }

    /**
     * 头部负载解析
     *
     * @param abstractExcelTemplate abstractExcelTemplate
     * @return list
     */
    public Map<String, Object> parseHeadPayload(Object abstractExcelTemplate) {
        Map<String, Object> ret = new HashMap<>(4);
        BeanMap beanMap = BeanMap.create(abstractExcelTemplate);
        final Field[] declaredFields = abstractExcelTemplate.getClass().getDeclaredFields();
        for (Field declaredField : declaredFields) {
            if (declaredField.isAnnotationPresent(HeadPayload.class)) {
                final Object o = beanMap.get(declaredField.getName());
                if (o != null) {
                    if ((o instanceof CharSequence) || o instanceof Number) {
                        ret.put(declaredField.getName(), beanMap.get(declaredField.getName()));
                    } else {
                        final BeanMap map = BeanMap.create(o);
                        final Field[] fields = o.getClass().getDeclaredFields();
                        for (Field field : fields) {
                            if (map.get(field.getName()) != null) {
                                ret.put(declaredField.getName() + "." + field.getName(), map.get(field.getName()));
                            }
                        }
                    }
                }
            }
        }
        return ret;
    }

    /**
     * 解析并实例化模板工厂
     *
     * @param templateClass templateClass
     * @return list
     * @throws IllegalAccessException IllegalAccessException
     * @throws InstantiationException InstantiationException
     */
    public ExcelSheetTemplateFactory parseTemplateFactory(Class<?> templateClass) throws IllegalAccessException, InstantiationException {
        Class<? extends ExcelSheetTemplateFactory> aClass;
        if (templateClass.isAnnotationPresent(ExcelSheet.class)) {
            aClass = templateClass.getAnnotation(ExcelSheet.class).templateFactory();
        } else {
            aClass = DefaultSheetTemplateFactory.class;
        }
        return aClass.newInstance();
    }
}
