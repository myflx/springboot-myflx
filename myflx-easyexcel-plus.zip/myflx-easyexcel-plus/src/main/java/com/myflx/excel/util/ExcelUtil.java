package com.myflx.excel.util;

import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.write.builder.ExcelWriterSheetBuilder;
import com.alibaba.excel.write.handler.CellWriteHandler;
import com.alibaba.excel.write.metadata.style.WriteCellStyle;
import com.alibaba.excel.write.style.HorizontalCellStyleStrategy;
import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import org.apache.commons.text.StringSubstitutor;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRichTextString;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.util.CellRangeAddress;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ExcelUtil {

    public static void main(String[] args) {
        // 定义excel标题
        String[] title = {"序\n号", "学号", "姓名", "身份证号", "成绩"};

        // 定义excel文件名
        String fileName = "五年级一班学生成绩单";

        // 定义sheet名
        String sheetName = "成绩单";


        // 创建HSSFWorkbook，写入sheet名称，标题名称，内容等信息
        HSSFWorkbook wb = ExcelUtil.getHSSFWorkbook1(fileName, sheetName, title, new String[][]{}, null);
        // 响应到客户端
        try {
            // 获取浏览器的user-agent参数，进行输出文件名称编码格式转换

            // 输出响应
            OutputStream os = new FileOutputStream(new File("D:/" + fileName + ".xls"));
            wb.write(os);
            os.flush();
            os.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        /*try {
            OutputStream os = new FileOutputStream(new File("D:/test.xls"));
            createExcel(os);
        }catch (Exception e){
            e.printStackTrace();
        }*/

        /*try {

            // 输出流
            OutputStream outputStream = null;
            outputStream = new FileOutputStream(new File("D:\\1.xlsx"));


            // 标题
            List<String> headList = Arrays.asList("*上海自来水来自上海", "*年龄", "*学校");

            String getSheetName = "导出文件";
            ExcelHeadHandler titleColorSheetWriteHandler =
                    new ExcelHeadHandler(Sets.newHashSet(0, 1, 2), Sets.newHashSet(0, 1, 2));
            ExcelHeadDescHandler titleColorSheetWriteHandler2 =
                    new ExcelHeadDescHandler(Sets.newHashSet(0, 1, 2), Sets.newHashSet(0, 1, 2));

            List<Integer> columnIndexs1 = Arrays.asList(0, 1);
            List<Integer> rowIndexs1 = Arrays.asList(1, 2, 3, 4);
            CellStyleSheetWriteHandler colorSheetWriteHandler = new CellStyleSheetWriteHandler(rowIndexs1, columnIndexs1, IndexedColors.BLACK.index);

            writeExcelWithModel(outputStream, new ArrayList<>(), headList, getSheetName, titleColorSheetWriteHandler, colorSheetWriteHandler);
        } catch (Exception e) {
            e.printStackTrace();
        }*/


        Map<String, String> paramMap = new HashMap<>();
        paramMap.put("name", "john");
        paramMap.put("name", "");
        paramMap.put("age", "27");
        //org.apache.commons.text.StringSubstitutor
        StringSubstitutor stringSubstitutor = new StringSubstitutor(paramMap);
        String template3 = "${name} is at the age of ${age}";
        String templateResult3 = stringSubstitutor.replace(template3);
        System.out.println(templateResult3);

    }


    public static void writeExcelWithModel(OutputStream outputStream, List<? extends Object> dataList, List<String> headList, String sheetName, CellWriteHandler... cellWriteHandlers) {
        List<List<String>> list = new ArrayList<>();
        if (headList != null) {
            headList.forEach(h -> {
                List<String> list1 = new ArrayList<>();
                list1.add(h);
                list.add(list1);
            });
        }
        //list.get(1).add("描述");
        // 头的策略
        WriteCellStyle headWriteCellStyle = new WriteCellStyle();
        // 单元格策略
        WriteCellStyle contentWriteCellStyle = new WriteCellStyle();
        // 初始化表格样式
        HorizontalCellStyleStrategy horizontalCellStyleStrategy = new HorizontalCellStyleStrategy(headWriteCellStyle, contentWriteCellStyle);

        ExcelWriterSheetBuilder excelWriterSheetBuilder = EasyExcel.write(outputStream).head(list).sheet(sheetName).registerWriteHandler(horizontalCellStyleStrategy);
//        ExcelWriterSheetBuilder excelWriterSheetBuilder = EasyExcel.write(outputStream).head(list).sheet(getSheetName).registerWriteHandler(horizontalCellStyleStrategy);
        if (null != cellWriteHandlers && cellWriteHandlers.length > 0) {
            for (int i = 0; i < cellWriteHandlers.length; i++) {
                excelWriterSheetBuilder.registerWriteHandler(cellWriteHandlers[i]);
            }
        }
        // 开始导出
        excelWriterSheetBuilder.doWrite(dataList);
    }

    /**
     * 导出表头必填字段标红色
     *
     * @param outputStream      输入流
     * @param dataList          导入数据
     * @param headList          表头列表
     * @param sheetName         sheetname
     * @param cellWriteHandlers
     */
    public static void writeExcelWithModel(OutputStream outputStream, List<? extends Object> dataList, Class<? extends Object> headList, String sheetName, CellWriteHandler... cellWriteHandlers) {

        // 头的策略
        WriteCellStyle headWriteCellStyle = new WriteCellStyle();
        // 单元格策略
        WriteCellStyle contentWriteCellStyle = new WriteCellStyle();
        // 初始化表格样式
        HorizontalCellStyleStrategy horizontalCellStyleStrategy = new HorizontalCellStyleStrategy(headWriteCellStyle, contentWriteCellStyle);

        ExcelWriterSheetBuilder excelWriterSheetBuilder = EasyExcel.write(outputStream, headList).sheet(sheetName).registerWriteHandler(horizontalCellStyleStrategy);
        if (null != cellWriteHandlers && cellWriteHandlers.length > 0) {
            for (int i = 0; i < cellWriteHandlers.length; i++) {
                excelWriterSheetBuilder.registerWriteHandler(cellWriteHandlers[i]);
            }
        }
        // 开始导出
        excelWriterSheetBuilder.doWrite(dataList);
    }


    /**
     * 导出Excel
     *
     * @param sheetName sheet名称
     * @param title     标题
     * @param values    内容
     * @param wb        HSSFWorkbook对象
     * @return
     */
    public static HSSFWorkbook getHSSFWorkbook1(String fileName, String sheetName, String[] title, String[][] values, HSSFWorkbook wb) {

        // 第一步，创建一个HSSFWorkbook，对应一个Excel文件
        if (wb == null) {
            wb = new HSSFWorkbook();
        }

        // 第二步，在workbook中添加一个sheet,对应Excel文件中的sheet
        HSSFSheet sheet = wb.createSheet(sheetName);

        // 设置当前sheet中默认的列宽为10个字符
        sheet.setDefaultColumnWidth(10);
        // 设置当前sheet中2,3,4列为12,15,20个字符
        sheet.setColumnWidth(2, 12 * 256);
        sheet.setColumnWidth(3, 15 * 256);
        sheet.setColumnWidth(4, 20 * 256);

        // 第三步，在第一行设置标题栏
        // 定义单元格的样式
        HSSFCellStyle cellStyle = wb.createCellStyle();
        // 设置字体样式，13号，加粗
        HSSFFont font1 = wb.createFont();
        font1.setFontHeightInPoints((short) 13);
        /*font1.setBoldweight(Font.BOLDWEIGHT_BOLD);*/
        font1.setBold(true);
        cellStyle.setFont(font1);
        // 设置水平居中
        /*cellStyle.setAlignment(CellStyle.ALIGN_CENTER);*/
        cellStyle.setAlignment(HorizontalAlignment.CENTER_SELECTION);
        // 标题栏所在sheet的行为第一行
        HSSFRow titleRow = sheet.createRow(0);
        // 设置行高
        titleRow.setHeight((short) 500);
        // 设置第一行的第一个单元格
        HSSFCell titleCell = titleRow.createCell(0);
        // 设置标题文本
        final HSSFRichTextString hssfRichTextString = new HSSFRichTextString(fileName);
        HSSFFont rfont = wb.createFont();
        rfont.setColor(HSSFColor.HSSFColorPredefined.RED.getIndex());
        rfont.setBold(true);
        rfont.setItalic(true);
        hssfRichTextString.applyFont(0, 5, rfont);
        titleCell.setCellValue(hssfRichTextString);
        // 设置单元格样式
        titleCell.setCellStyle(cellStyle);
        // 处理单元格合并，四个参数分别是：起始行，终止行，起始行，终止列
        sheet.addMergedRegion(new CellRangeAddress(0, 0, (short) 0, (short) (title.length - 1)));
        // 设置合并后的单元格的样式
        titleRow.createCell(title.length - 1).setCellStyle(cellStyle);

        // 第四步，在sheet中添加标题行，位于表头第1行,注意老版本poi对Excel的行数列数有限制
        HSSFRow row = sheet.createRow(1);
        // 创建title行cell样式
        HSSFCellStyle style = wb.createCellStyle();

        style.setWrapText(true);
        // 设置title样式剧中
        style.setAlignment(HorizontalAlignment.CENTER_SELECTION);
        // 设置字体
        HSSFFont font = wb.createFont();
        font.setFontHeightInPoints((short) 13);
        font.setBold(true);
        style.setFont(font);
        style.setFillBackgroundColor(HSSFColor.HSSFColorPredefined.RED.getIndex());
        // 声明列对象
        HSSFCell cell = null;
        // 创建标题
        for (int i = 0; i < title.length; i++) {
            // 创建cell
            cell = row.createCell(i);
            // 填入内容
            cell.setCellValue(title[i]);
            // 设置cell内容的样式
            cell.setCellStyle(style);
        }

        // 第五步，在sheet中添加内容，位于表头第2行开始
        // 定义内容cell样式
        HSSFCellStyle styleContent = wb.createCellStyle();
        // 设置样式 居中，字体，边框
        /*styleContent.setAlignment(CellStyle.ALIGN_CENTER);*/
        styleContent.setAlignment(HorizontalAlignment.CENTER_SELECTION);
        font = wb.createFont();
        font.setFontHeightInPoints((short) 11);
        styleContent.setFont(font);
        styleContent.setFillBackgroundColor(HSSFColor.HSSFColorPredefined.RED.getIndex());
        // 设置边框样式
        /*styleContent.setBorderBottom(HSSFCellStyle.BORDER_THIN);
        styleContent.setBorderLeft(HSSFCellStyle.BORDER_THIN);
        styleContent.setBorderTop(HSSFCellStyle.BORDER_THIN);
        styleContent.setBorderRight(HSSFCellStyle.BORDER_THIN);*/
        // 创建内容
        for (int i = 0; i < values.length; i++) {
            row = sheet.createRow(i + 2);
            titleRow.setHeight((short) 500);
            for (int j = 0; j < values[i].length; j++) {
                // 将内容按顺序赋给对应的列对象
                HSSFCell createCell = row.createCell(j);
                createCell.setCellValue(values[i][j]);
                createCell.setCellStyle(style);
            }
        }
        return wb;
    }


    public static void createExcel(OutputStream os) throws WriteException, IOException {
        //创建工作薄
        WritableWorkbook workbook = Workbook.createWorkbook(os);
        //创建新的一页
        WritableSheet sheet = workbook.createSheet("First Sheet", 0);
        //创建要显示的内容,创建一个单元格，第一个参数为列坐标，第二个参数为行坐标，第三个参数为内容
        Label xuexiao = new Label(0, 0, "学校");
        sheet.addCell(xuexiao);
        Label zhuanye = new Label(1, 0, "专业");
        sheet.addCell(zhuanye);
        Label jingzhengli = new Label(2, 0, "专业竞争力");
        sheet.addCell(jingzhengli);

        Label qinghua = new Label(0, 1, "清华大学");
        sheet.addCell(qinghua);
        Label jisuanji = new Label(1, 1, "计算机专业");
        sheet.addCell(jisuanji);
        Label gao = new Label(2, 1, "高");
        sheet.addCell(gao);

        Label beida = new Label(0, 2, "北京大学");
        sheet.addCell(beida);
        Label falv = new Label(1, 2, "法律专业");
        sheet.addCell(falv);
        Label zhong = new Label(2, 2, "中");
        sheet.addCell(zhong);

        Label ligong = new Label(0, 3, "北京理工大学");
        sheet.addCell(ligong);
        Label hangkong = new Label(1, 3, "航空专业");
        sheet.addCell(hangkong);
        Label di = new Label(2, 3, "低");
        sheet.addCell(di);

        //把创建的内容写入到输出流中，并关闭输出流
        workbook.write();
        workbook.close();
        os.close();
    }
}
