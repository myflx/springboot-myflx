package com.myflx.excel.handler;

import com.alibaba.excel.write.style.row.AbstractRowHeightStyleStrategy;
import com.myflx.excel.ExcelSheetTemplate;
import com.myflx.excel.holder.CellParam;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.poi.ss.usermodel.Row;

import java.util.List;

/**
 * 自适应高度
 *
 * @author LuoShangLin
 */
public class HeightHandler extends AbstractRowHeightStyleStrategy {
    private static final int DEFAULT_HEIGHT = 256;
    private ExcelSheetTemplate templateBean;

    public HeightHandler(ExcelSheetTemplate templateBean) {
        this.templateBean = templateBean;
    }

    @Override
    protected void setHeadColumnHeight(Row row, int relativeRowIndex) {
        int max = 1;
        if (templateBean.isAutoHeight()) {
            final List<List<CellParam>> sourceHeadList = templateBean.getSourceHeadList();
            final List<CellParam> cellList = sourceHeadList.get(row.getRowNum());
            for (CellParam excelCell : cellList) {
                if (excelCell.isRich() && ArrayUtils.isNotEmpty(excelCell.getRichValues())) {
                    max = Math.max(max, excelCell.getRichValues().length);
                }
            }
        }
        row.setHeight((short) (templateBean.getHeadHeight() * DEFAULT_HEIGHT * max));
    }


    @Override
    protected void setContentColumnHeight(Row row, int relativeRowIndex) {
        row.setHeight((short) (templateBean.getBodyHeight() * DEFAULT_HEIGHT));
    }
}
