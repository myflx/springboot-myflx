package com.myflx.excel;

import com.myflx.excel.holder.CellParam;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * excelTemplateBean for export excel
 *
 * @author LuoShangLin
 */
public interface ExcelSheetTemplate extends HeadPayload, BodyPayload {

    /**
     * 内容字体高度
     *
     * @return short
     */
    Short bodyFontHeightInPoints();

    /**
     * 头部字体高度
     *
     * @return short
     */
    Short headFontHeightInPoints();

    /**
     * 行加粗
     *
     * @return map
     */
    Set<Integer> rowBold();

    /**
     * 行加粗
     *
     * @param rowIndex 行索引
     */
    void addRowBold(Integer rowIndex);

    /**
     * 行对齐方式
     *
     * @return map
     */
    Map<Integer, HorizontalAlignment> rowHorizontalAlignment();

    /**
     * 添加单行对齐方式
     *
     * @param rowIndex  行索引
     * @param alignment 对齐方式
     */
    void addRowHorizontalAlignment(Integer rowIndex, HorizontalAlignment alignment);

    /**
     * 单行颜色
     *
     * @return map
     */
    Map<Integer, IndexedColors> rowBgColor();

    /**
     * 添加单行背景颜色
     *
     * @param rowIndex 行索引
     * @param colors   色值
     */
    void addRowBgColor(Integer rowIndex, IndexedColors colors);

    /**
     * Auto Height
     *
     * @return Boolean
     */
    boolean isAutoHeight();

    /**
     * Head Height
     *
     * @return float
     */
    float getHeadHeight();


    /**
     * body Height
     *
     * @return float
     */
    float getBodyHeight();

    /**
     * 模板关联的处理器工厂
     *
     * @return ExcelHandlerFactory
     */
    ExcelHandlerFactory getHandlerFactory();

    /**
     * 返回目标头部列表
     *
     * @return list
     */
    List<List<String>> headList();

    /**
     * 返回头部元列表
     *
     * @return list
     */
    List<List<CellParam>> getSourceHeadList();

    /**
     * 返回sheet名称
     *
     * @return str
     */
    String getSheetName();

    /**
     * set factory
     *
     * @param handlerFactory handlerFactory
     */
    void setHandlerFactory(ExcelHandlerFactory handlerFactory);
}
