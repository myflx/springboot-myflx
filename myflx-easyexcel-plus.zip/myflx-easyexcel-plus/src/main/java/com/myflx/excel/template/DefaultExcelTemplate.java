package com.myflx.excel.template;

import com.myflx.excel.impl.DefaultExcelHandlerFactory;

/**
 * standard excel template
 *
 * @author LuoShangLin
 */
public class DefaultExcelTemplate extends AbstractExcelTemplate {
    public DefaultExcelTemplate(Object target) {
        super(target);
        this.setHandlerFactory(new DefaultExcelHandlerFactory(this));
    }


}
