package com.myflx.excel.handler;

import com.alibaba.excel.metadata.CellData;
import com.alibaba.excel.metadata.Head;
import com.alibaba.excel.write.handler.AbstractCellWriteHandler;
import com.alibaba.excel.write.metadata.holder.WriteSheetHolder;
import com.alibaba.excel.write.metadata.holder.WriteTableHolder;
import com.myflx.excel.HeadPayload;
import com.myflx.excel.parsing.GenericTokenParser;
import com.google.common.collect.Maps;
import org.apache.commons.collections.MapUtils;
import org.apache.poi.ss.usermodel.Cell;

import java.util.List;
import java.util.Map;

/**
 * @author LuoShangLin
 */
public abstract class AbstractPayloadHandler extends AbstractCellWriteHandler {
    private Map<String, Object> headPayload;

    public AbstractPayloadHandler(HeadPayload payLoad) {
        final Map<String, Object> payload = payLoad.getHeadPayload();
        this.headPayload = MapUtils.isEmpty(payload) ? Maps.newHashMap() : MapUtils.unmodifiableMap(payload);
    }

    /**
     * get token replace handler
     *
     * @param headPayload headPayload
     * @return GenericTokenParser
     */
    protected abstract GenericTokenParser getTokenParser(Map<String, Object> headPayload);

    @Override
    public void afterCellDispose(WriteSheetHolder writeSheetHolder, WriteTableHolder writeTableHolder, List<CellData> list, Cell cell, Head head, Integer integer, Boolean isHead) {
        if (!isHead) {
            return;
        }
        final GenericTokenParser tokenParser = this.getTokenParser(headPayload);
        if (tokenParser == null) {
            return;
        }
        cell.setCellValue(tokenParser.parse(cell.getStringCellValue()));
    }
}
