package com.myflx.excel.util;


import com.myflx.excel.ExcelSheetTemplate;
import com.myflx.excel.ExcelSheetTemplateFactory;
import com.myflx.excel.holder.ExcelTemplateHolder;
import com.myflx.excel.holder.SheetLoadHolder;
import org.apache.commons.collections.CollectionUtils;

import javax.servlet.http.HttpServletResponse;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * @author LuoShangLin
 */
public class FeExcelSheetBuilder {

    private SheetLoadHolder sheetLoadHolder;

    private List<FeExcelSheetBuilder> nextSheetBuilders;


    FeExcelSheetBuilder(Object templateBean) {
        this.sheetLoadHolder = new SheetLoadHolder(templateBean);
    }

    public FeExcelSheetBuilder addBuilder(FeExcelSheetBuilder builder) {
        if (nextSheetBuilders == null) {
            nextSheetBuilders = new ArrayList<>();
        }
        if (builder != null) {
            nextSheetBuilders.add(builder);
        }
        return this;
    }

    public List<FeExcelSheetBuilder> getNextSheetBuilders() {
        return nextSheetBuilders;
    }

    public SheetLoadHolder getSheetLoadHolder() {
        return sheetLoadHolder;
    }

    /**
     * bodyPayload
     *
     * @param bodyPayload bodyPayload
     * @return builder
     */
    public FeExcelSheetBuilder addPayLoad(List<Object> bodyPayload) {
        this.sheetLoadHolder.setBodyPayload(bodyPayload);
        return this;
    }

    /**
     * export
     *
     * @param outputStream outputStream
     */
    public void export(OutputStream outputStream) {
        final ExcelSheetTemplateFactory sheetTemplateFactory = ExcelTemplateHolder.getSheetTemplateFactory(sheetLoadHolder.getTemplateBean());
        FeExcels.export(outputStream, sheetTemplateFactory.getObject(sheetLoadHolder));
    }

    /**
     * exportAll
     *
     * @param outputStream outputStream
     */
    public void exportAll(OutputStream outputStream) {
        List<ExcelSheetTemplate> templates = new ArrayList<>();
        final ExcelSheetTemplateFactory sheetTemplateFactory = ExcelTemplateHolder.getSheetTemplateFactory(this.getSheetLoadHolder().getTemplateBean());
        templates.add(sheetTemplateFactory.getObject(this.getSheetLoadHolder()));
        if (CollectionUtils.isNotEmpty(nextSheetBuilders)) {
            for (FeExcelSheetBuilder nextSheetBuilder : nextSheetBuilders) {
                final ExcelSheetTemplateFactory templateFactory = ExcelTemplateHolder.getSheetTemplateFactory(nextSheetBuilder.getSheetLoadHolder().getTemplateBean());
                templates.add(templateFactory.getObject(nextSheetBuilder.getSheetLoadHolder()));
            }
        }
        FeExcels.export(outputStream, templates);
    }

    /**
     * export
     *
     * @param fileName fileName
     * @param response response
     */
    public void export(String fileName, HttpServletResponse response) {
        final ExcelSheetTemplateFactory sheetTemplateFactory = ExcelTemplateHolder.getSheetTemplateFactory(sheetLoadHolder.getTemplateBean());
        FeExcels.export(fileName, response, sheetTemplateFactory.getObject(sheetLoadHolder));
    }
}
